import './bootstrap.js';
import '@coreui/coreui/dist/js/coreui.bundle.min.js';

$(function () {
    $('[data-toggle="tooltip"]').tooltip()
})

