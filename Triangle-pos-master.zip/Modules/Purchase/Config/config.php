<?php

return [
    'name' => 'Purchase'
];
