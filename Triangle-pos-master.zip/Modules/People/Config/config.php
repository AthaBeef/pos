<?php

return [
    'name' => 'People'
];
